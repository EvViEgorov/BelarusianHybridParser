# Belarusian Hybrid Parser

A rule-based belarusian language parser with neural model hints feature

## Installation

```
pip install -i https://test.pypi.org/simple/ BelarusianHybridParser
```

## Usage

